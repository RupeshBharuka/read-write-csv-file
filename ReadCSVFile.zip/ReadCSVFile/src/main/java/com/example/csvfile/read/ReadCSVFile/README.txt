1)Reading CSV File,
   App, App2 and App3 are the example of reading csv file in a different way
   
2)Generating a CSV File,