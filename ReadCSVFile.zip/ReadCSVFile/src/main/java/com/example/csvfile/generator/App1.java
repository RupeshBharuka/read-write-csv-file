package com.example.csvfile.generator;

import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

public class App1 {
	//just specify path and name of file to be generated and it'll automatically generate the csv file for you 
	private static final String CSV_FILE_PATH = "/home/agsuser/Desktop/test3.csv";
	
	public static void main(String[] args) throws IOException {
		 
		try(Writer writer = Files.newBufferedWriter(Paths.get(CSV_FILE_PATH));
		 CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT
				 									.withHeader("Id","Name","Designation","Company"));){
	/*		
	 * Note: If you don't print any record then it will generate csv file with the specified header only and not with the content
	 * 		 But if you want csv to be generated with content then you have to use the printRecord() method as given below,
	 * 
			printer.printRecord("1","Sundar Pichai", "CEO", "Google");
			printer.printRecord("2","Satya Nadella", "CEO", "Microsoft");
			printer.printRecord("3","Mark Zuckerberg", "CEO", "Facebook");
			*/
			printer.flush();
		}
		 
	}

}
