package com.example.csvfile.read.ReadCSVFile;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/*
 * Parses CSV files according to the specified format. Because CSV appears in many different dialects, 
 * the parser supports many formats by allowing the specification of a CSVFormat. The parser works record wise. 
 * It is not possible to go back, once a record has been parsed from the input stream.
 * */
public class App 
{
	private static final String CSV_FILE_PATH = "/home/agsuser/Desktop/test.csv";
	
    public static void main( String[] args ) throws IOException
    {
    	//try with resource
    	try(Reader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH));
    	CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);)/*default is standard comma separated format*/{
    		
    		for(CSVRecord record : csvParser){
    			//Accessing value by colom index
    			String name = record.get(0);
    			String email = record.get(1);
    			String phone = record.get(2);
    			String country = record.get(3);
    			
    			System.out.println("Record Number : " +record.getRecordNumber());
    			
    			System.out.println("Name : " +name);
    			System.out.println("Email : " +email);
    			System.out.println("Phone No : " +phone);
    			System.out.println("Counrty : " +country);
     			System.out.println("--------------------------------------");   
    		}
    		
    	/*	
    	 * 	The CSVParser class also provides a method called getRecords() to read all the records at once into memory
    	 *  But you should avoid this method if you’re reading a significantly large CSV file. You might run into memory 
    	 *  issues because the getRecords() method loads the entire CSV contents into memory.
    	 * 
    	 * List<CSVRecord> csvRecord = csvParser.getRecords(); 
    		csvRecord.forEach(r -> {
    			//Accessing value by colom index
    			String name = r.get(0);
    			String email = r.get(1);
    			String phone = r.get(2);
    			String country = r.get(3);
    			
    			System.out.println("Record Number : " +r.getRecordNumber());
    			
    			System.out.println("Name : " +name);
    			System.out.println("Email : " +email);
    			System.out.println("Phone No : " +phone);
    			System.out.println("Counrty : " +country);
     			System.out.println("--------------------------------------");
    		});*/
    	}
    	
    }
}
